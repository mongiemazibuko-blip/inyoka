/* Real-time layer: WebSocket (cross-device via Cloudflare Worker) */
const Realtime = (() => {
  let ws = null;
  let status = 'off'; // off | connecting | live | error
  let reconnectTimer = null;
  let pingTimer = null;
  let intentionalClose = false;
  let onRemoteChange = null; // async (msg) => {}
  let onStatus = null;       // (status) => {}

  const cfg = () => (typeof CONFIG !== 'undefined' ? CONFIG : {});

  function setStatus(s) {
    status = s;
    if (onStatus) onStatus(s);
    const el = document.getElementById('rtStatus');
    if (el) {
      el.textContent = s === 'live' ? 'Live' : s === 'connecting' ? 'Connecting…' : s === 'error' ? 'Offline sync' : 'Local';
      el.className = 'rt-status ' + s;
      el.title = s === 'live'
        ? 'WebSocket connected — changes sync in real time'
        : s === 'connecting'
          ? 'Connecting to live server…'
          : 'Using local data only (set CONFIG.wsUrl to enable WebSocket)';
    }
  }

  function publishLocal(msg) {
    const payload = Object.assign({ t: Date.now() }, msg);
    sendWs(payload);
  }

  /* ---------- WebSocket ---------- */
  function wsUrl() {
    const u = cfg().wsUrl;
    if (u) return u;
    // Same-origin worker path if deployed with Pages + Worker route
    if (location.protocol === 'https:' || location.protocol === 'http:') {
      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      return proto + '//' + location.host + '/ws';
    }
    return null;
  }

  function connect() {
    const url = wsUrl();
    if (!url || typeof WebSocket === 'undefined') {
      setStatus('off');
      return;
    }
    // Only attempt auto same-origin if explicit wsUrl is set, or if host is not file://
    // Avoid noisy reconnects when no worker is deployed: only connect when CONFIG.wsUrl is set
    if (!cfg().wsUrl) {
      setStatus('off');
      return;
    }
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
    intentionalClose = false;
    setStatus('connecting');
    try {
      ws = new WebSocket(url);
    } catch (e) {
      setStatus('error');
      scheduleReconnect();
      return;
    }
    ws.onopen = () => {
      setStatus('live');
      clearTimeout(reconnectTimer);
      sendWs({ type: 'hello', user: (typeof ME !== 'undefined' && ME) ? ME.username : 'anon', app: 'fidelity-adt-snake-portal' });
      sendWs({ type: 'sync:request' });
      clearInterval(pingTimer);
      pingTimer = setInterval(() => {
        if (ws && ws.readyState === WebSocket.OPEN) sendWs({ type: 'ping' });
      }, 25000);
    };
    ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      if (!msg || !msg.type) return;
      if (msg.type === 'pong' || msg.type === 'hello:ok') return;
      handleIncoming(msg, 'ws');
    };
    ws.onerror = () => { /* onclose will follow */ };
    ws.onclose = () => {
      clearInterval(pingTimer);
      ws = null;
      if (!intentionalClose) {
        setStatus('error');
        scheduleReconnect();
      } else setStatus('off');
    };
  }

  function scheduleReconnect() {
    clearTimeout(reconnectTimer);
    if (!cfg().wsUrl) return;
    reconnectTimer = setTimeout(connect, 4000 + Math.random() * 2000);
  }

  function sendWs(obj) {
    if (!ws || ws.readyState !== WebSocket.OPEN) return false;
    try {
      const out = Object.assign({}, obj);
      if (out.report && out.report.photo && out.report.photo.length > 80000) {
        out.report = Object.assign({}, out.report, { photo: null, photoOmitted: true });
      }
      ws.send(JSON.stringify(out));
      return true;
    } catch (e) { return false; }
  }

  async function handleIncoming(msg, source) {
    if (onRemoteChange) {
      try { await onRemoteChange(msg, source); } catch (e) { console.warn('realtime handler', e); }
    }
  }

  /* ---------- public API ---------- */
  function start(handlers) {
    onRemoteChange = handlers && handlers.onRemoteChange;
    onStatus = handlers && handlers.onStatus;
    connect();
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && status !== 'live' && cfg().wsUrl) connect();
    });
  }

  function stop() {
    intentionalClose = true;
    clearTimeout(reconnectTimer);
    clearInterval(pingTimer);
    if (ws) try { ws.close(); } catch (e) { /* ignore */ }
    ws = null;
    setStatus('off');
  }

  function notifyReportSave(report) {
    publishLocal({ type: 'report:save', report });
  }

  function notifyReportDelete(id) {
    publishLocal({ type: 'report:delete', id });
  }

  function notifyUsersChanged() {
    publishLocal({ type: 'users:changed' });
  }

  function getStatus() { return status; }
  function isLive() { return status === 'live'; }

  return { start, stop, notifyReportSave, notifyReportDelete, notifyUsersChanged, getStatus, isLive, connect };
})();
window.Realtime = Realtime;
